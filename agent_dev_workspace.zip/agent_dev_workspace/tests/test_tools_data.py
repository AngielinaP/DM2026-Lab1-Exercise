import matplotlib.figure
import pandas as pd
import pytest
from agent_pipeline.session_state import SessionState
from agent_pipeline.workspace_loader import load_workspace_tools
from tools_data import make_tools


def test_tokenize_tool_fixture():
    session = SessionState()

    # Load premade tools to run load_dataset_tool
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")

    # Load sample_fixture.csv
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    # Save a copy of the original 'text' column values before tokenizing
    original_text = session.dataframe["text"].tolist()

    # Initialize tools from tools_data.py
    tools = make_tools(session)
    tokenize_tool = next(t for t in tools if t.name == "tokenize_tool")

    # Run tokenize_tool
    result = tokenize_tool.invoke({})

    # Check summary return dict
    assert "result_id" in result
    assert result["n_documents"] == 8
    assert result["total_tokens"] == 27

    # Verify that the original 'text' column is unchanged
    assert session.dataframe["text"].tolist() == original_text

    # Verify all 8 token lists match Known Answer #10 exactly
    expected_unigrams = [
        ["always", "alpha", "alpha", "alpha", "beta"],
        ["always", "alpha", "alpha", "beta"],
        ["always", "alpha", "beta"],
        ["always", "gamma", "gamma", "gamma", "delta"],
        ["always", "gamma", "gamma", "delta"],
        ["always", "gamma", "delta"],
        ["always", "gamma", "delta"],
        [],
    ]

    actual_unigrams = session.dataframe["unigrams"].tolist()
    assert actual_unigrams == expected_unigrams


def test_list_files_tool_fixture():
    session = SessionState()

    # Directly instantiate make_tools from tools_data with fresh session
    tools = make_tools(session)
    list_files_tool = next(t for t in tools if t.name == "list_files_tool")

    # Invoke list_files_tool against "newdataset"
    result = list_files_tool.invoke({"subdirectory": "newdataset"})

    # Check assertions matching TEST_FIXTURE.md Known Answer #11
    assert result["subdirectory"] == "newdataset"
    assert result["directories"] == []
    assert result["files"] == ["Reddit-stock-sentiment.csv"]


def test_check_missing_tool_fixture():
    session = SessionState()

    # Load premade tools to run load_dataset_tool
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")

    # Load sample_fixture.csv into session.dataframe
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    # Save a deep copy of session.dataframe before calling check_missing_tool
    df_before = session.dataframe.copy(deep=True)

    # Initialize check_missing_tool from tools_data using the SAME session
    tools = make_tools(session)
    check_missing_tool = next(t for t in tools if t.name == "check_missing_tool")

    # Invoke check_missing_tool
    result = check_missing_tool.invoke({})

    # Assert returned values match Known Answer #2
    assert "result_id" in result
    assert result["missing_count"] == 1
    assert result["total_rows"] == 8
    assert result["missing_positions"] == [7]
    assert result["missing_pct"] == pytest.approx(12.5, rel=1e-3)

    # Verify that session.dataframe was left completely unchanged using assert_frame_equal
    pd.testing.assert_frame_equal(session.dataframe, df_before)


def test_check_duplicates_tool_reporting_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    df_before = session.dataframe.copy(deep=True)

    # Initialize tools
    tools = make_tools(session)
    check_duplicates_tool = next(
        t for t in tools if t.name == "check_duplicates_tool"
    )

    # Test drop=False (Reporting mode)
    result = check_duplicates_tool.invoke({"drop": False})

    assert "result_id" in result
    assert result["n_duplicates"] == 1
    assert result["drop"] is False
    assert result["n_rows_before"] == 8
    assert result["n_rows_after"] == 8
    assert result["rows_dropped"] == 0

    # Ensure dataframe is untouched
    pd.testing.assert_frame_equal(session.dataframe, df_before)


def test_check_duplicates_tool_dropping_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    # Initialize tools
    tools = make_tools(session)
    check_duplicates_tool = next(
        t for t in tools if t.name == "check_duplicates_tool"
    )

    # Test drop=True (Dropping mode with keep=False)
    result = check_duplicates_tool.invoke({"drop": True})

    assert "result_id" in result
    assert result["n_duplicates"] == 1
    assert result["drop"] is True
    assert result["n_rows_before"] == 8
    assert result["n_rows_after"] == 6
    assert result["rows_dropped"] == 2
    assert len(session.dataframe) == 6


def test_sample_data_tool_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    tools = make_tools(session)
    sample_data_tool = next(t for t in tools if t.name == "sample_data_tool")

    # Call sample_data_tool(n=4, random_state=42)
    result = sample_data_tool.invoke({"n": 4, "random_state": 42})

    assert "result_id" in result
    assert result["n_rows_before"] == 8
    assert result["n_rows_after"] == 4
    # Check exact sampled row indices in order matching Known Answer #13
    assert result["sampled_indices"] == [1, 5, 0, 7]

    # Verify session.dataframe index labels match sampled_indices in order
    assert session.dataframe.index.tolist() == [1, 5, 0, 7]
    assert len(session.dataframe) == 4


def test_describe_data_tool_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    df_before = session.dataframe.copy(deep=True)

    tools = make_tools(session)
    describe_data_tool = next(t for t in tools if t.name == "describe_data_tool")

    # Reset pending figure before invoking
    session.pending_figure = None

    result = describe_data_tool.invoke({})

    assert "result_id" in result

    # Assert Known Answer #18 overall statistics with numerical tolerance
    overall = result["overall_stats"]
    assert overall["count"] == 8
    assert overall["mean"] == pytest.approx(19.875, rel=1e-3)
    assert overall["std"] == pytest.approx(9.4330, rel=1e-3)
    assert overall["min"] == 0
    assert overall["25%"] == pytest.approx(17.75, rel=1e-3)
    assert overall["50%"] == pytest.approx(20.5, rel=1e-3)
    assert overall["75%"] == pytest.approx(25.25, rel=1e-3)
    assert overall["max"] == 30

    # Assert Known Answer #18 per-category statistics (including 25% and 75%)
    cat_stats = result["per_category_stats"]
    assert "catA" in cat_stats
    assert "catB" in cat_stats

    catA = cat_stats["catA"]
    assert catA["count"] == 4
    assert catA["mean"] == pytest.approx(17.25, rel=1e-3)
    assert catA["std"] == pytest.approx(12.5, rel=1e-3)
    assert catA["min"] == 0
    assert catA["25%"] == pytest.approx(12.75, rel=1e-3)
    assert catA["50%"] == pytest.approx(20.0, rel=1e-3)
    assert catA["75%"] == pytest.approx(24.5, rel=1e-3)
    assert catA["max"] == 29

    catB = cat_stats["catB"]
    assert catB["count"] == 4
    assert catB["mean"] == pytest.approx(22.5, rel=1e-3)
    assert catB["std"] == pytest.approx(5.7446, rel=1e-3)
    assert catB["min"] == 18
    assert catB["25%"] == pytest.approx(18.0, rel=1e-3)
    assert catB["50%"] == pytest.approx(21.0, rel=1e-3)
    assert catB["75%"] == pytest.approx(25.5, rel=1e-3)
    assert catB["max"] == 30

    # Verify session.dataframe was left completely unchanged using assert_frame_equal
    pd.testing.assert_frame_equal(session.dataframe, df_before)

    # Assert pending figure created
    assert session.pending_figure is not None
    assert isinstance(session.pending_figure, matplotlib.figure.Figure)
