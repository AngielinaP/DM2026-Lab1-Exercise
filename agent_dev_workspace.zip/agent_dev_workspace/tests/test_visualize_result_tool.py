import matplotlib.figure
import pandas as pd
import pytest
from agent_pipeline.session_state import SessionState
from agent_pipeline.workspace_loader import load_workspace_tools


def test_visualize_result_tool():
    session = SessionState()
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    visualize_result_tool = next(
        t for t in premade_tools if t.name == "visualize_result_tool"
    )

    # 1. Store a mock full_report DataFrame as if a filtering tool created it
    result_id = session.next_result_id("variance_filter")
    mock_df = pd.DataFrame(
        {
            "term": ["alpha", "gamma", "delta", "beta", "always"],
            "variance": [1.1875, 1.109375, 0.25, 0.234375, 0.109375],
        }
    )

    session.store_result(
        tool_name="variance_filter_tool",
        args={"threshold": 0.15},
        summary={"result_id": result_id, "n_kept": 4},
        full_report=mock_df,
    )

    # Ensure no figure is pending prior to tool invocation
    session.pending_figure = None

    # 2. Invoke visualize_result_tool with top_n=3
    output = visualize_result_tool.invoke({"result_id": result_id, "top_n": 3})

    # 3. Assertions
    assert session.pending_figure is not None
    assert isinstance(session.pending_figure, matplotlib.figure.Figure)

    ax = session.pending_figure.gca()

    # Check for exactly 3 bar patches on the axes
    patches = ax.patches
    assert len(patches) == 3, f"Expected 3 bar patches for top_n=3, found {len(patches)}"

    # visualize_result_tool renders horizontal bar charts (`sns.barplot(x=..., y=...)` where y is terms/labels, x is values)
    # or vertical bar charts where x is terms/labels and y is values.
    # We inspect both x and y tick labels to determine which axis holds the category term strings.
    x_labels = [label.get_text() for label in ax.get_xticklabels()]
    y_labels = [label.get_text() for label in ax.get_yticklabels()]

    expected_labels = ["alpha", "gamma", "delta"]
    expected_values = [1.1875, 1.109375, 0.25]

    if y_labels and y_labels[:3] == expected_labels:
        # Horizontal layout: y-axis holds labels, x-axis/patch widths hold numerical values
        labels = y_labels[:3]
        heights_or_widths = [p.get_width() for p in patches]
    else:
        # Vertical layout: x-axis holds labels, y-axis/patch heights hold numerical values
        labels = x_labels[:3]
        heights_or_widths = [p.get_height() for p in patches]

    # Strictly assert exact labels in order
    assert labels == expected_labels, f"Expected labels {expected_labels}, got {labels}"

    # Assert bar dimensions match expected numerical values using numerical tolerance
    assert heights_or_widths == pytest.approx(expected_values, rel=1e-3), (
        f"Expected bar values {expected_values}, got {heights_or_widths}"
    )
