import pytest
from agent_pipeline.session_state import SessionState
from agent_pipeline.workspace_loader import load_workspace_tools
from tools_patterns import make_tools


def test_mine_patterns_tool_fpgrowth_tfidf_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    tools = make_tools(session)
    mine_patterns_tool = next(t for t in tools if t.name == "mine_patterns_tool")

    # Test catA with tfidf & fpgrowth (min_sup=1)
    res_catA = mine_patterns_tool.invoke(
        {
            "category_name": "catA",
            "filtering_method": "tfidf",
            "algorithm": "fpgrowth",
            "min_sup": 1,
        }
    )

    assert "result_id" in res_catA
    assert res_catA["kept_terms"] == ["alpha"]
    assert len(res_catA["patterns"]) == 1
    assert res_catA["patterns"][0]["pattern"] == ["alpha"]
    assert res_catA["patterns"][0]["support"] == 3

    # Test catB with tfidf & fpgrowth (min_sup=1)
    res_catB = mine_patterns_tool.invoke(
        {
            "category_name": "catB",
            "filtering_method": "tfidf",
            "algorithm": "fpgrowth",
            "min_sup": 1,
        }
    )

    assert res_catB["kept_terms"] == ["gamma"]
    assert len(res_catB["patterns"]) == 1
    assert res_catB["patterns"][0]["pattern"] == ["gamma"]
    assert res_catB["patterns"][0]["support"] == 4


def test_mine_patterns_tool_zero_terms_survived_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    tools = make_tools(session)
    mine_patterns_tool = next(t for t in tools if t.name == "mine_patterns_tool")

    # Test variance filtering on catA (Known Answer #17: 0 terms survive filtering)
    res_var = mine_patterns_tool.invoke(
        {
            "category_name": "catA",
            "filtering_method": "variance",
            "algorithm": "fpgrowth",
            "min_sup": 1,
        }
    )

    assert res_var["patterns"] == []
    assert res_var["kept_terms"] == []
    assert res_var["note"] == "no terms survived filtering"


def test_mine_patterns_tool_topk_and_maxfpgrowth_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    tools = make_tools(session)
    mine_patterns_tool = next(t for t in tools if t.name == "mine_patterns_tool")

    # Test algorithm="topk" (k=1) on catA with tfidf
    res_topk = mine_patterns_tool.invoke(
        {
            "category_name": "catA",
            "filtering_method": "tfidf",
            "algorithm": "topk",
            "k": 1,
        }
    )

    assert res_topk["kept_terms"] == ["alpha"]
    assert len(res_topk["patterns"]) == 1
    assert res_topk["patterns"][0]["pattern"] == ["alpha"]
    assert res_topk["patterns"][0]["support"] == 3

    # Test algorithm="maxfpgrowth" (min_sup=1) on catA with tfidf (Known Answer #20: 0 patterns returned)
    res_max = mine_patterns_tool.invoke(
        {
            "category_name": "catA",
            "filtering_method": "tfidf",
            "algorithm": "maxfpgrowth",
            "min_sup": 1,
        }
    )

    assert res_max["kept_terms"] == ["alpha"]
    assert res_max["patterns"] == []
