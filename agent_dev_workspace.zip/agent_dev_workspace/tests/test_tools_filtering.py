import pytest
from agent_pipeline.session_state import SessionState
from agent_pipeline.workspace_loader import load_workspace_tools
from tools_dtm import make_tools as make_dtm_tools
from tools_filtering import make_tools as make_filtering_tools


def test_variance_filter_tool_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    # Build DTM first
    dtm_tools = make_dtm_tools(session)
    build_dtm_tool = next(t for t in dtm_tools if t.name == "build_dtm_tool")
    build_dtm_tool.invoke({})

    # Initialize filtering tools
    filtering_tools = make_filtering_tools(session)
    variance_filter_tool = next(
        t for t in filtering_tools if t.name == "variance_filter_tool"
    )

    # Invoke variance_filter_tool with threshold=0.15
    result = variance_filter_tool.invoke({"threshold": 0.15})

    # Assert Known Answer #5 variances with numerical tolerance
    assert "result_id" in result
    assert result["threshold"] == 0.15

    variances = result["variances"]
    assert variances["alpha"] == pytest.approx(1.1875, rel=1e-3)
    assert variances["always"] == pytest.approx(0.109375, rel=1e-3)
    assert variances["beta"] == pytest.approx(0.234375, rel=1e-3)
    assert variances["delta"] == pytest.approx(0.25, rel=1e-3)
    assert variances["gamma"] == pytest.approx(1.109375, rel=1e-3)

    # Assert kept vs removed terms at threshold=0.15
    # threshold 0.15 keeps alpha, beta, delta, gamma and removes always
    assert sorted(result["kept_terms"]) == ["alpha", "beta", "delta", "gamma"]
    assert result["removed_terms"] == ["always"]

    # Assert session.feature_matrix remained unchanged
    assert session.feature_matrix.shape == (8, 5)

    # Assert full_report stored in results_store
    stored_res = session.results_store[result["result_id"]]
    assert stored_res["full_report"] is not None
    report_df = stored_res["full_report"]

    assert list(report_df.columns) == ["term", "variance"]
    assert report_df["term"].tolist() == ["alpha", "gamma", "delta", "beta", "always"]
    assert report_df["variance"].tolist() == pytest.approx(
        [1.1875, 1.109375, 0.25, 0.234375, 0.109375], rel=1e-3
    )


def test_pearson_filter_tool_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    # Build DTM first
    dtm_tools = make_dtm_tools(session)
    build_dtm_tool = next(t for t in dtm_tools if t.name == "build_dtm_tool")
    build_dtm_tool.invoke({})

    # Initialize filtering tools
    filtering_tools = make_filtering_tools(session)
    pearson_filter_tool = next(
        t for t in filtering_tools if t.name == "pearson_filter_tool"
    )

    # Invoke pearson_filter_tool with target_class="catB" and threshold=0.5
    result = pearson_filter_tool.invoke({"target_class": "catB", "threshold": 0.5})

    assert "result_id" in result
    assert result["target_class"] == "catB"
    assert result["threshold"] == 0.5

    # Assert Known Answer #6 Pearson r numbers
    pearsons = result["pearson_correlations"]
    assert pearsons["alpha"] == pytest.approx(-0.6882, rel=1e-3)
    assert pearsons["always"] == pytest.approx(0.3780, rel=1e-3)
    assert pearsons["beta"] == pytest.approx(-0.7746, rel=1e-3)
    assert pearsons["delta"] == pytest.approx(1.0000, rel=1e-3)
    assert pearsons["gamma"] == pytest.approx(0.8307, rel=1e-3)

    # Assert kept vs removed terms at threshold=0.5 (abs(r) > 0.5)
    assert sorted(result["kept_terms"]) == ["alpha", "beta", "delta", "gamma"]
    assert result["removed_terms"] == ["always"]
    assert result["undefined_terms"] == []

    # Verify full_report columns and descending abs(r) sorting
    stored_res = session.results_store[result["result_id"]]
    assert stored_res["full_report"] is not None
    report_df = stored_res["full_report"]

    assert list(report_df.columns) == ["term", "pearson_r"]
    # Sorting by descending abs(r): delta (1.0), gamma (0.8307), beta (-0.7746), alpha (-0.6882), always (0.3780)
    assert report_df["term"].tolist() == ["delta", "gamma", "beta", "alpha", "always"]
    assert report_df["pearson_r"].tolist() == pytest.approx(
        [1.0000, 0.8307, -0.7746, -0.6882, 0.3780], rel=1e-3
    )


def test_spearman_filter_tool_fixture():
    session = SessionState()

    # Load dataset
    premade_tools, _ = load_workspace_tools("premade_tools", session)
    load_dataset_tool = next(t for t in premade_tools if t.name == "load_dataset_tool")
    load_dataset_tool.invoke(
        {
            "file_path": "agent_dev/sample_fixture.csv",
            "text_column": "text",
            "label_column": "label",
        }
    )

    # Build DTM first
    dtm_tools = make_dtm_tools(session)
    build_dtm_tool = next(t for t in dtm_tools if t.name == "build_dtm_tool")
    build_dtm_tool.invoke({})

    # Initialize filtering tools
    filtering_tools = make_filtering_tools(session)
    spearman_filter_tool = next(
        t for t in filtering_tools if t.name == "spearman_filter_tool"
    )

    # Invoke spearman_filter_tool with target_class="catB" and threshold=0.5
    result = spearman_filter_tool.invoke({"target_class": "catB", "threshold": 0.5})

    assert "result_id" in result
    assert result["target_class"] == "catB"
    assert result["threshold"] == 0.5

    # Assert Known Answer #6 Spearman r numbers
    spearmans = result["spearman_correlations"]
    assert spearmans["alpha"] == pytest.approx(-0.7500, rel=1e-3)
    assert spearmans["always"] == pytest.approx(0.3780, rel=1e-3)
    assert spearmans["beta"] == pytest.approx(-0.7746, rel=1e-3)
    assert spearmans["delta"] == pytest.approx(1.0000, rel=1e-3)
    assert spearmans["gamma"] == pytest.approx(0.9363, rel=1e-3)

    # Assert kept vs removed terms at threshold=0.5 (abs(r) > 0.5)
    assert sorted(result["kept_terms"]) == ["alpha", "beta", "delta", "gamma"]
    assert result["removed_terms"] == ["always"]
    assert result["undefined_terms"] == []

    # Verify full_report columns and descending abs(r) sorting
    stored_res = session.results_store[result["result_id"]]
    assert stored_res["full_report"] is not None
    report_df = stored_res["full_report"]

    assert list(report_df.columns) == ["term", "spearman_r"]
    # Sorting by descending abs(r): delta (1.0), gamma (0.9363), beta (-0.7746), alpha (-0.7500), always (0.3780)
    assert report_df["term"].tolist() == ["delta", "gamma", "beta", "alpha", "always"]
    assert report_df["spearman_r"].tolist() == pytest.approx(
        [1.0000, 0.9363, -0.7746, -0.7500, 0.3780], rel=1e-3
    )
