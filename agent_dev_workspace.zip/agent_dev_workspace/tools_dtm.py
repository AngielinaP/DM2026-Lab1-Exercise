from typing import Any, Dict

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from langchain_core.tools import tool
from sklearn.feature_extraction.text import CountVectorizer


def make_tools(session):
    @tool
    def build_dtm_tool() -> Dict[str, Any]:
        """Build the unigram document-term matrix from session.dataframe['text'].

        Uses sklearn's CountVectorizer with default settings (lowercasing enabled,
        no stop words removed, unigrams). Stores the matrix in session.feature_matrix,
        vocabulary in session.feature_names, fitted vectorizer in session.artifacts['count_vectorizer'],
        and aligns category labels via session.set_labels.

        Returns:
            A summary dictionary containing result_id, n_documents, n_features,
            non_zero, total_elements, and sparsity_pct.
        """
        if session.dataframe is None:
            return {"status": "error", "message": "No dataset loaded in session.dataframe."}

        if "text" not in session.dataframe.columns:
            return {
                "status": "error",
                "message": "'text' column not found in session.dataframe.",
            }

        # Fill missing text/NaN with empty string "" so CountVectorizer processes all rows
        texts = session.dataframe["text"].fillna("").astype(str).tolist()

        vectorizer = CountVectorizer()
        feature_matrix = vectorizer.fit_transform(texts)
        feature_names = vectorizer.get_feature_names_out().tolist()

        # Update session state attributes
        session.feature_matrix = feature_matrix
        session.feature_names = feature_names
        session.artifacts["count_vectorizer"] = vectorizer

        if "category_name" in session.dataframe.columns:
            session.set_labels(session.dataframe["category_name"].values)

        n_documents, n_features = feature_matrix.shape
        non_zero = int(feature_matrix.nnz)
        total_elements = int(n_documents * n_features)

        if total_elements > 0:
            sparsity_pct = float(round(100.0 * (1.0 - non_zero / total_elements), 4))
        else:
            sparsity_pct = 0.0

        result_id = session.next_result_id("build_dtm")
        summary = {
            "result_id": result_id,
            "n_documents": n_documents,
            "n_features": n_features,
            "non_zero": non_zero,
            "total_elements": total_elements,
            "sparsity_pct": sparsity_pct,
        }

        session.store_result(
            tool_name="build_dtm_tool",
            args={},
            summary=summary,
        )

        return summary

    @tool
    def term_frequency_tool() -> Dict[str, Any]:
        """Aggregate total term frequencies across all documents in session.feature_matrix.

        Sums column values across session.feature_matrix to obtain total term frequencies.
        Leaves the document-term matrix and feature names unchanged.

        Returns:
            A summary dictionary containing result_id, term_frequencies, n_features,
            and total_term_occurrences.
        """
        if session.feature_matrix is None or session.feature_names is None:
            return {
                "status": "error",
                "message": (
                    "Document-term matrix or feature names not found in session. "
                    "Please run build_dtm_tool first."
                ),
            }

        # Sum vertically across rows (documents) for each term column
        column_sums = np.asarray(session.feature_matrix.sum(axis=0)).flatten()

        term_frequencies = {
            term: int(count)
            for term, count in zip(session.feature_names, column_sums)
        }

        n_features = len(session.feature_names)
        total_term_occurrences = int(column_sums.sum())

        result_id = session.next_result_id("term_frequency")
        summary = {
            "result_id": result_id,
            "term_frequencies": term_frequencies,
            "n_features": n_features,
            "total_term_occurrences": total_term_occurrences,
        }

        session.store_result(
            tool_name="term_frequency_tool",
            args={},
            summary=summary,
        )

        return summary

    @tool
    def dtm_heatmap_tool(n_terms: int = 20, n_documents: int = 20) -> Dict[str, Any]:
        """Render a raw positional slice of session.feature_matrix as a heatmap.

        Slices the top n_documents rows and top n_terms columns in their existing
        positional order. Uses session.dataframe index labels (converted to strings) as
        document labels. Generates an annotated Seaborn heatmap in session.pending_figure.

        Args:
            n_terms: Number of vocabulary terms to include (default: 20).
            n_documents: Number of document rows to include (default: 20).

        Returns:
            A summary dictionary containing result_id, matrix, terms, and documents.
        """
        if session.feature_matrix is None or session.feature_names is None:
            return {
                "status": "error",
                "message": (
                    "Document-term matrix or feature names not found in session. "
                    "Please run build_dtm_tool first."
                ),
            }

        if n_terms <= 0:
            return {
                "status": "error",
                "message": f"n_terms={n_terms} must be greater than 0.",
            }

        if n_documents <= 0:
            return {
                "status": "error",
                "message": f"n_documents={n_documents} must be greater than 0.",
            }

        total_docs, total_terms = session.feature_matrix.shape

        slice_docs = min(n_documents, total_docs)
        slice_terms = min(n_terms, total_terms)

        matrix_slice = session.feature_matrix[:slice_docs, :slice_terms].toarray()
        matrix_list = [[int(val) for val in row] for row in matrix_slice]

        terms = session.feature_names[:slice_terms]

        if session.dataframe is not None and len(session.dataframe) >= slice_docs:
            documents = [str(idx) for idx in session.dataframe.index[:slice_docs].tolist()]
        else:
            documents = [f"Doc {i}" for i in range(slice_docs)]

        # Render Heatmap
        fig, ax = plt.subplots(figsize=(max(6, slice_terms * 0.8), max(4, slice_docs * 0.5)))
        sns.heatmap(
            matrix_slice,
            xticklabels=terms,
            yticklabels=documents,
            annot=True,
            fmt="d",
            cmap="YlGnBu",
            cbar=True,
            ax=ax,
        )
        ax.set_title(f"DTM Heatmap ({slice_docs} Documents x {slice_terms} Terms)")
        ax.set_xlabel("Terms")
        ax.set_ylabel("Document Index")
        plt.tight_layout()

        session.pending_figure = fig

        result_id = session.next_result_id("dtm_heatmap")
        summary = {
            "result_id": result_id,
            "matrix": matrix_list,
            "terms": terms,
            "documents": documents,
        }

        session.store_result(
            tool_name="dtm_heatmap_tool",
            args={"n_terms": n_terms, "n_documents": n_documents},
            summary=summary,
        )

        return summary

    return [build_dtm_tool, term_frequency_tool, dtm_heatmap_tool]
