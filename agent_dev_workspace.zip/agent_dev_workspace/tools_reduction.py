from typing import Any, Dict, Literal, Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from langchain_core.tools import tool
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import umap


def make_tools(session):
    @tool
    def reduce_dimensions_tool(
        method: Literal["pca", "tsne", "umap"] = "pca",
        perplexity: Optional[float] = None,
        n_neighbors: Optional[int] = None,
        random_state: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Reduce DTM dimensionality to 2D coordinates and generate a category-colored scatter plot.

        Supports PCA, t-SNE, and UMAP reduction. Uses session.feature_matrix as input
        and aligns category colors using session.labels. Sets session.pending_figure
        with the generated scatter plot. Leaves session.feature_matrix and labels unchanged.

        Args:
            method: Reduction algorithm ('pca', 'tsne', or 'umap', default: 'pca').
            perplexity: Perplexity parameter for t-SNE (must be strictly > 0 and < n_documents).
            n_neighbors: Number of neighbors parameter for UMAP (must be integer between 2 and n_documents - 1).
            random_state: Optional seed for reproducible randomized reduction.

        Returns:
            A summary dictionary containing result_id, method, coordinates,
            and explained_variance_ratio (for PCA).
        """
        if session.feature_matrix is None or session.feature_names is None:
            return {
                "status": "error",
                "message": (
                    "Document-term matrix or feature names not found in session. "
                    "Please run build_dtm_tool first."
                ),
            }

        if session.labels is None:
            return {
                "status": "error",
                "message": "Category labels (session.labels) not found in session.",
            }

        n_docs, n_features = session.feature_matrix.shape
        if len(session.labels) != n_docs:
            return {
                "status": "error",
                "message": (
                    f"Label count ({len(session.labels)}) does not match DTM row count ({n_docs})."
                ),
            }

        dense_dtm = session.feature_matrix.toarray()
        explained_variance_ratio = None

        if method == "pca":
            if n_docs < 2 or n_features < 2:
                return {
                    "status": "error",
                    "message": "PCA requires at least 2 documents and 2 features to produce 2D coordinates.",
                }
            pca = PCA(n_components=2)
            coords_arr = pca.fit_transform(dense_dtm)
            explained_variance_ratio = [float(v) for v in pca.explained_variance_ratio_.tolist()]

        elif method == "tsne":
            perp = perplexity if perplexity is not None else min(30.0, float(max(1, n_docs - 1)))
            if perp <= 0 or perp >= n_docs:
                return {
                    "status": "error",
                    "message": f"t-SNE perplexity={perp} must be strictly greater than 0 and less than total documents ({n_docs}).",
                }
            tsne = TSNE(n_components=2, perplexity=perp, random_state=random_state)
            coords_arr = tsne.fit_transform(dense_dtm)

        elif method == "umap":
            n_neigh = n_neighbors if n_neighbors is not None else min(15, max(2, n_docs - 1))
            if n_neigh < 2 or n_neigh >= n_docs:
                return {
                    "status": "error",
                    "message": f"UMAP n_neighbors={n_neigh} must be an integer between 2 and {n_docs - 1}.",
                }
            reducer = umap.UMAP(n_components=2, n_neighbors=n_neigh, random_state=random_state)
            coords_arr = reducer.fit_transform(dense_dtm)

        else:
            return {"status": "error", "message": f"Unsupported method '{method}'."}

        coords_list = [
            [float(row[0]), float(row[1])] for row in coords_arr
        ]

        # Generate Scatter Plot
        fig, ax = plt.subplots(figsize=(8, 6))
        sns.scatterplot(
            x=coords_arr[:, 0],
            y=coords_arr[:, 1],
            hue=list(session.labels),
            style=list(session.labels),
            s=100,
            ax=ax,
        )
        ax.set_title(f"2D Dimensionality Reduction ({method.upper()})")
        ax.set_xlabel("Dimension 1")
        ax.set_ylabel("Dimension 2")
        plt.tight_layout()

        session.pending_figure = fig

        result_id = session.next_result_id("reduce_dimensions")
        summary = {
            "result_id": result_id,
            "method": method,
            "coordinates": coords_list,
        }
        if explained_variance_ratio is not None:
            summary["explained_variance_ratio"] = explained_variance_ratio

        session.store_result(
            tool_name="reduce_dimensions_tool",
            args={
                "method": method,
                "perplexity": perplexity,
                "n_neighbors": n_neighbors,
                "random_state": random_state,
            },
            summary=summary,
        )

        return summary

    return [reduce_dimensions_tool]
