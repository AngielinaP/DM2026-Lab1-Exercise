from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from langchain_core.tools import tool


def make_tools(session):
    @tool
    def variance_filter_tool(threshold: float = 0.0) -> Dict[str, Any]:
        """Filter terms by population variance (ddof=0) across all documents in session.feature_matrix.

        Computes variance natively on the sparse DTM using column means and mean-squares,
        avoiding dense matrix conversion. Keeps terms with variance strictly greater than threshold,
        flagging terms with variance at or below threshold for removal. Leaves session.feature_matrix unchanged.

        Args:
            threshold: Variance threshold for keeping terms (default: 0.0).

        Returns:
            A summary dictionary containing result_id, threshold, variances,
            kept_terms, and removed_terms.
        """
        if session.feature_matrix is None or session.feature_names is None:
            return {
                "status": "error",
                "message": (
                    "Document-term matrix or feature names not found in session. "
                    "Please run build_dtm_tool first."
                ),
            }

        # Sparse-native population variance (ddof=0) calculation: E[X^2] - (E[X])^2
        # Convert matrix to float copy to prevent integer overflow when squaring counts
        dtm_float = session.feature_matrix.astype(np.float64)

        means = np.asarray(dtm_float.mean(axis=0)).flatten()
        mean_sq = np.asarray(dtm_float.multiply(dtm_float).mean(axis=0)).flatten()

        variances_arr = mean_sq - (means ** 2)

        # Clamp tiny negative variances caused by floating-point rounding arithmetic to 0.0
        variances_arr = np.maximum(variances_arr, 0.0)

        term_variances = {
            term: float(round(var_val, 4))
            for term, var_val in zip(session.feature_names, variances_arr)
        }

        kept_terms = []
        removed_terms = []

        for term, var_val in zip(session.feature_names, variances_arr):
            if var_val > threshold:
                kept_terms.append(term)
            else:
                removed_terms.append(term)

        # Build full_report DataFrame for visualize_result_tool
        report_df = pd.DataFrame(
            {
                "term": session.feature_names,
                "variance": [float(round(v, 4)) for v in variances_arr],
            }
        ).sort_values(by="variance", ascending=False).reset_index(drop=True)

        result_id = session.next_result_id("variance_filter")
        summary = {
            "result_id": result_id,
            "threshold": threshold,
            "variances": term_variances,
            "kept_terms": kept_terms,
            "removed_terms": removed_terms,
        }

        session.store_result(
            tool_name="variance_filter_tool",
            args={"threshold": threshold},
            summary=summary,
            full_report=report_df,
        )

        return summary

    @tool
    def pearson_filter_tool(target_class: str, threshold: float = 0.0) -> Dict[str, Any]:
        """Compute Pearson correlation between term counts and a target class (one-vs-rest).

        Filter terms where absolute correlation abs(r) > threshold. Constant term columns
        have undefined correlation (reported as None in JSON summary, NaN in full_report,
        and listed in undefined_terms and removed_terms).

        Args:
            target_class: Target category name for one-vs-rest binary correlation.
            threshold: Minimum absolute correlation threshold for keeping terms (default: 0.0).

        Returns:
            A summary dictionary containing result_id, target_class, threshold,
            pearson_correlations, kept_terms, removed_terms, and undefined_terms.
        """
        if session.feature_matrix is None or session.feature_names is None:
            return {
                "status": "error",
                "message": (
                    "Document-term matrix or feature names not found in session. "
                    "Please run build_dtm_tool first."
                ),
            }

        if session.labels is None:
            return {
                "status": "error",
                "message": "Category labels (session.labels) not found in session.",
            }

        n_docs = session.feature_matrix.shape[0]
        if len(session.labels) != n_docs:
            return {
                "status": "error",
                "message": (
                    f"Label count ({len(session.labels)}) does not match DTM row count ({n_docs})."
                ),
            }

        labels_list = list(session.labels)
        if target_class not in labels_list:
            return {
                "status": "error",
                "message": f"Target class '{target_class}' not found in session labels.",
            }

        # Create binary target y (1 for target_class, 0 for rest)
        y = np.array([1.0 if L == target_class else 0.0 for L in labels_list], dtype=np.float64)

        if np.std(y) == 0.0:
            return {
                "status": "error",
                "message": (
                    f"Target class '{target_class}' contains no variation "
                    "(all documents belong to this class or no documents match)."
                ),
            }

        pearson_correlations: Dict[str, Optional[float]] = {}
        kept_terms = []
        removed_terms = []
        undefined_terms = []

        raw_r_list = []
        abs_r_list = []

        for i, term in enumerate(session.feature_names):
            # Process one sparse column at a time
            x = session.feature_matrix[:, i].toarray().flatten().astype(np.float64)
            std_x = np.std(x)

            if std_x == 0.0:
                pearson_correlations[term] = None
                undefined_terms.append(term)
                removed_terms.append(term)
                raw_r_list.append(np.nan)
                abs_r_list.append(-1.0)  # For sorting NaNs last
            else:
                raw_r = float(np.corrcoef(x, y)[0, 1])
                r_val_rounded = float(round(raw_r, 4))
                pearson_correlations[term] = r_val_rounded
                raw_r_list.append(r_val_rounded)

                abs_r_val = abs(raw_r)  # Threshold & sort using unrounded abs(r)
                abs_r_list.append(abs_r_val)

                if abs_r_val > threshold:
                    kept_terms.append(term)
                else:
                    removed_terms.append(term)

        # Build full_report DataFrame for visualize_result_tool
        report_df = pd.DataFrame(
            {
                "term": session.feature_names,
                "pearson_r": raw_r_list,
                "_abs_r": abs_r_list,
            }
        ).sort_values(by="_abs_r", ascending=False).drop(columns=["_abs_r"]).reset_index(drop=True)

        result_id = session.next_result_id("pearson_filter")
        summary = {
            "result_id": result_id,
            "target_class": target_class,
            "threshold": threshold,
            "pearson_correlations": pearson_correlations,
            "kept_terms": kept_terms,
            "removed_terms": removed_terms,
            "undefined_terms": undefined_terms,
        }

        session.store_result(
            tool_name="pearson_filter_tool",
            args={"target_class": target_class, "threshold": threshold},
            summary=summary,
            full_report=report_df,
        )

        return summary

    @tool
    def spearman_filter_tool(target_class: str, threshold: float = 0.0) -> Dict[str, Any]:
        """Compute Spearman rank correlation between term counts and a target class (one-vs-rest).

        Processes one term column at a time without converting the whole DTM to dense.
        Filter terms where absolute rank correlation abs(r) > threshold using unrounded values.
        Constant term columns have undefined correlation (reported as None in JSON summary,
        NaN in full_report, and listed in undefined_terms and removed_terms).

        Args:
            target_class: Target category name for one-vs-rest binary correlation.
            threshold: Minimum absolute rank correlation threshold for keeping terms (default: 0.0).

        Returns:
            A summary dictionary containing result_id, target_class, threshold,
            spearman_correlations, kept_terms, removed_terms, and undefined_terms.
        """
        if session.feature_matrix is None or session.feature_names is None:
            return {
                "status": "error",
                "message": (
                    "Document-term matrix or feature names not found in session. "
                    "Please run build_dtm_tool first."
                ),
            }

        if session.labels is None:
            return {
                "status": "error",
                "message": "Category labels (session.labels) not found in session.",
            }

        n_docs = session.feature_matrix.shape[0]
        if len(session.labels) != n_docs:
            return {
                "status": "error",
                "message": (
                    f"Label count ({len(session.labels)}) does not match DTM row count ({n_docs})."
                ),
            }

        labels_list = list(session.labels)
        if target_class not in labels_list:
            return {
                "status": "error",
                "message": f"Target class '{target_class}' not found in session labels.",
            }

        # Create binary target y (1 for target_class, 0 for rest)
        y = np.array([1.0 if L == target_class else 0.0 for L in labels_list], dtype=np.float64)

        if np.std(y) == 0.0:
            return {
                "status": "error",
                "message": (
                    f"Target class '{target_class}' contains no variation "
                    "(all documents belong to this class or no documents match)."
                ),
            }

        spearman_correlations: Dict[str, Optional[float]] = {}
        kept_terms = []
        removed_terms = []
        undefined_terms = []

        raw_r_list = []
        abs_r_list = []

        for i, term in enumerate(session.feature_names):
            # Process one sparse column at a time
            x = session.feature_matrix[:, i].toarray().flatten().astype(np.float64)
            std_x = np.std(x)

            if std_x == 0.0:
                spearman_correlations[term] = None
                undefined_terms.append(term)
                removed_terms.append(term)
                raw_r_list.append(np.nan)
                abs_r_list.append(-1.0)  # For sorting NaNs last
            else:
                rho_res = spearmanr(x, y)
                raw_rho = float(rho_res.statistic) if hasattr(rho_res, 'statistic') else float(rho_res[0])
                r_val_rounded = float(round(raw_rho, 4))
                spearman_correlations[term] = r_val_rounded
                raw_r_list.append(r_val_rounded)

                abs_rho_val = abs(raw_rho)  # Threshold & sort using unrounded abs(rho)
                abs_r_list.append(abs_rho_val)

                if abs_rho_val > threshold:
                    kept_terms.append(term)
                else:
                    removed_terms.append(term)

        # Build full_report DataFrame for visualize_result_tool
        report_df = pd.DataFrame(
            {
                "term": session.feature_names,
                "spearman_r": raw_r_list,
                "_abs_r": abs_r_list,
            }
        ).sort_values(by="_abs_r", ascending=False).drop(columns=["_abs_r"]).reset_index(drop=True)

        result_id = session.next_result_id("spearman_filter")
        summary = {
            "result_id": result_id,
            "target_class": target_class,
            "threshold": threshold,
            "spearman_correlations": spearman_correlations,
            "kept_terms": kept_terms,
            "removed_terms": removed_terms,
            "undefined_terms": undefined_terms,
        }

        session.store_result(
            tool_name="spearman_filter_tool",
            args={"target_class": target_class, "threshold": threshold},
            summary=summary,
            full_report=report_df,
        )

        return summary

    return [variance_filter_tool, pearson_filter_tool, spearman_filter_tool]
