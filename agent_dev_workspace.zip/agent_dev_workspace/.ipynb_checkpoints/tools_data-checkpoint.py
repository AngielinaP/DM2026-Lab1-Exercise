from pathlib import Path
from typing import Any, Dict, Optional

import matplotlib.pyplot as plt
import nltk
import pandas as pd
import seaborn as sns
from langchain_core.tools import tool


def _ensure_nltk_tokenizer():
    """Ensure NLTK's punkt tokenizer data is available, attempting download if missing.

    Raises RuntimeError if resources cannot be found or downloaded.
    """
    for resource in ["punkt_tab", "punkt"]:
        try:
            nltk.data.find(f"tokenizers/{resource}")
            return  # Resource found
        except LookupError:
            try:
                nltk.download(resource, quiet=True)
                nltk.data.find(f"tokenizers/{resource}")
                return  # Download succeeded
            except Exception:
                continue

    raise RuntimeError(
        "NLTK tokenizer data ('punkt' or 'punkt_tab') is missing and could not be downloaded automatically. "
        "Please install it manually by running: python -m nltk.downloader punkt_tab"
    )


def make_tools(session):
    @tool
    def tokenize_tool() -> Dict[str, Any]:
        """Tokenize document text in session.dataframe into unigrams using NLTK word_tokenize.

        Reads session.dataframe['text'], converts non-empty text to lowercase,
        and tokenizes it into unigrams using nltk.word_tokenize.
        Stores the resulting token lists as a new 'unigrams' column in session.dataframe,
        leaving the original 'text' column untouched.

        Returns:
            A summary dictionary containing result_id, n_documents, total_tokens,
            and sample_tokens for the first document.
        """
        if session.dataframe is None:
            return {"status": "error", "message": "No dataset loaded in session.dataframe."}

        if "text" not in session.dataframe.columns:
            return {
                "status": "error",
                "message": "'text' column not found in session.dataframe.",
            }

        try:
            _ensure_nltk_tokenizer()
        except RuntimeError as e:
            return {"status": "error", "message": str(e)}

        def _tokenize_text(text: Any) -> list:
            if pd.isna(text) or not isinstance(text, str) or not text.strip():
                return []
            return nltk.word_tokenize(text.lower())

        # Tokenize without modifying original text
        tokens_series = session.dataframe["text"].apply(_tokenize_text)

        # Assign to session.dataframe['unigrams'] only after successful tokenization
        session.dataframe["unigrams"] = tokens_series

        total_tokens = int(tokens_series.apply(len).sum())
        n_documents = len(session.dataframe)

        sample_tokens = tokens_series.iloc[0] if n_documents > 0 else []

        result_id = session.next_result_id("tokenize")
        summary = {
            "result_id": result_id,
            "n_documents": n_documents,
            "total_tokens": total_tokens,
            "sample_tokens": sample_tokens,
        }

        session.store_result(
            tool_name="tokenize_tool",
            args={},
            summary=summary,
        )

        return summary

    @tool
    def list_files_tool(subdirectory: str = "") -> Dict[str, Any]:
        """List immediate files and subdirectories within a repository path.

        Discovers dataset files and folders starting from the repository root (Path.cwd()).
        Must be executed with current working directory set to the repository root.

        Args:
            subdirectory: Optional relative folder path from the repository root (default: "").

        Returns:
            A summary dictionary containing result_id, subdirectory, sorted directories list,
            and sorted files list.
        """
        base_dir = Path.cwd()
        target_path = (base_dir / subdirectory).resolve()

        if not target_path.exists():
            return {
                "status": "error",
                "message": f"Path '{subdirectory}' does not exist.",
            }

        if not target_path.is_dir():
            return {
                "status": "error",
                "message": f"Path '{subdirectory}' is a file, not a directory.",
            }

        directories = sorted([d.name for d in target_path.iterdir() if d.is_dir()])
        files = sorted([f.name for f in target_path.iterdir() if f.is_file()])

        result_id = session.next_result_id("list_files")
        summary = {
            "result_id": result_id,
            "subdirectory": subdirectory,
            "directories": directories,
            "files": files,
        }

        session.store_result(
            tool_name="list_files_tool",
            args={"subdirectory": subdirectory},
            summary=summary,
        )

        return summary

    @tool
    def check_missing_tool() -> Dict[str, Any]:
        """Check session.dataframe['text'] for missing or empty text values.

        Identifies null values (NaN, None) or strings that are empty after stripping whitespace.
        Leaves session.dataframe unchanged.

        Returns:
            A summary dictionary containing result_id, missing_count, total_rows,
            missing_pct, and missing_positions (zero-based positional indices).
        """
        if session.dataframe is None:
            return {"status": "error", "message": "No dataset loaded in session.dataframe."}

        if "text" not in session.dataframe.columns:
            return {
                "status": "error",
                "message": "'text' column not found in session.dataframe.",
            }

        df = session.dataframe
        total_rows = len(df)

        if total_rows == 0:
            result_id = session.next_result_id("check_missing")
            summary = {
                "result_id": result_id,
                "missing_count": 0,
                "total_rows": 0,
                "missing_pct": 0.0,
                "missing_positions": [],
            }
            session.store_result(
                tool_name="check_missing_tool",
                args={},
                summary=summary,
            )
            return summary

        missing_positions = []
        for pos, val in enumerate(df["text"]):
            if pd.isna(val) or val is None or (isinstance(val, str) and not val.strip()):
                missing_positions.append(pos)

        missing_count = len(missing_positions)
        missing_pct = float(round(100.0 * missing_count / total_rows, 4))

        result_id = session.next_result_id("check_missing")
        summary = {
            "result_id": result_id,
            "missing_count": missing_count,
            "total_rows": total_rows,
            "missing_pct": missing_pct,
            "missing_positions": missing_positions,
        }

        session.store_result(
            tool_name="check_missing_tool",
            args={},
            summary=summary,
        )

        return summary

    @tool
    def check_duplicates_tool(drop: bool = False) -> Dict[str, Any]:
        """Check for and optionally drop duplicate rows across all columns in session.dataframe.

        When drop=False, identifies duplicate rows without modifying session.dataframe.
        When drop=True, removes all instances of duplicate rows using keep=False.

        Args:
            drop: Whether to remove duplicate rows from session.dataframe (default: False).

        Returns:
            A summary dictionary containing result_id, n_duplicates, drop,
            n_rows_before, n_rows_after, and rows_dropped.
        """
        if session.dataframe is None:
            return {"status": "error", "message": "No dataset loaded in session.dataframe."}

        df = session.dataframe
        n_rows_before = len(df)

        # Calculate n_duplicates across all columns before dropping
        n_duplicates = int(df.duplicated(keep="first").sum())

        if drop:
            df.drop_duplicates(keep=False, inplace=True)
            n_rows_after = len(df)
            rows_dropped = n_rows_before - n_rows_after
        else:
            n_rows_after = n_rows_before
            rows_dropped = 0

        result_id = session.next_result_id("check_duplicates")
        summary = {
            "result_id": result_id,
            "n_duplicates": n_duplicates,
            "drop": drop,
            "n_rows_before": n_rows_before,
            "n_rows_after": n_rows_after,
            "rows_dropped": rows_dropped,
        }

        session.store_result(
            tool_name="check_duplicates_tool",
            args={"drop": drop},
            summary=summary,
        )

        return summary

    @tool
    def sample_data_tool(n: int, random_state: Optional[int] = None) -> Dict[str, Any]:
        """Subsample session.dataframe down to n rows without replacement.

        Must be called before building the document-term matrix (session.feature_matrix).
        Preserves original DataFrame index labels in sampled order. Re-syncs session.labels
        if category_name exists in session.dataframe.

        Args:
            n: Required number of rows to sample without replacement.
            random_state: Optional random seed for reproducible sampling.

        Returns:
            A summary dictionary containing result_id, n_rows_before, n_rows_after,
            and sampled_indices (original DataFrame index labels in sampled order).
        """
        if session.dataframe is None:
            return {"status": "error", "message": "No dataset loaded in session.dataframe."}

        if session.feature_matrix is not None:
            return {
                "status": "error",
                "message": (
                    "Sampling must be performed before building the document-term matrix "
                    "(session.feature_matrix already exists)."
                ),
            }

        n_rows_before = len(session.dataframe)

        if n <= 0:
            return {
                "status": "error",
                "message": f"Sample size n={n} must be greater than 0.",
            }

        if n > n_rows_before:
            return {
                "status": "error",
                "message": (
                    f"Requested sample size n={n} exceeds available rows ({n_rows_before})."
                ),
            }

        sampled_df = session.dataframe.sample(
            n=n, random_state=random_state, replace=False
        )

        session.dataframe = sampled_df
        sampled_indices = [int(idx) for idx in sampled_df.index.tolist()]

        if "category_name" in session.dataframe.columns:
            session.set_labels(session.dataframe["category_name"].values)

        result_id = session.next_result_id("sample_data")
        summary = {
            "result_id": result_id,
            "n_rows_before": n_rows_before,
            "n_rows_after": n,
            "sampled_indices": sampled_indices,
        }

        session.store_result(
            tool_name="sample_data_tool",
            args={"n": n, "random_state": random_state},
            summary=summary,
        )

        return summary

    @tool
    def describe_data_tool() -> Dict[str, Any]:
        """Compute summary statistics on document text length and produce a box plot by category.

        Measures text_length as character count on a working copy without altering session.dataframe.
        Generates overall and per-category .describe() summary statistics, builds a seaborn.boxplot,
        and sets session.pending_figure.

        Returns:
            A summary dictionary containing result_id, overall_stats, and per_category_stats.
        """
        if session.dataframe is None:
            return {"status": "error", "message": "No dataset loaded in session.dataframe."}

        if "text" not in session.dataframe.columns:
            return {
                "status": "error",
                "message": "'text' column not found in session.dataframe.",
            }

        if "category_name" not in session.dataframe.columns:
            return {
                "status": "error",
                "message": "'category_name' column not found in session.dataframe.",
            }

        df = session.dataframe.copy()

        def _get_length(val: Any) -> int:
            if pd.isna(val) or val is None:
                return 0
            if not isinstance(val, str):
                raise ValueError(f"Non-string value encountered in text column: {type(val)}")
            return len(val)

        try:
            df["text_length"] = df["text"].apply(_get_length)
        except ValueError as e:
            return {"status": "error", "message": str(e)}

        overall_series = df["text_length"].describe()
        overall_stats = {k: float(round(v, 4)) for k, v in overall_series.to_dict().items()}

        per_category_stats = {}
        for cat, group in df.groupby("category_name"):
            cat_desc = group["text_length"].describe().to_dict()
            per_category_stats[str(cat)] = {
                k: float(round(v, 4)) for k, v in cat_desc.items()
            }

        # Create Seaborn box plot
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.boxplot(data=df, x="category_name", y="text_length", ax=ax)
        ax.set_title("Document Text Length by Category")
        ax.set_xlabel("Category Name")
        ax.set_ylabel("Text Length (character count)")

        # Set pending figure for notebook rendering
        session.pending_figure = fig

        result_id = session.next_result_id("describe_data")
        summary = {
            "result_id": result_id,
            "overall_stats": overall_stats,
            "per_category_stats": per_category_stats,
        }

        session.store_result(
            tool_name="describe_data_tool",
            args={},
            summary=summary,
        )

        return summary

    return [
        tokenize_tool,
        list_files_tool,
        check_missing_tool,
        check_duplicates_tool,
        sample_data_tool,
        describe_data_tool,
    ]
