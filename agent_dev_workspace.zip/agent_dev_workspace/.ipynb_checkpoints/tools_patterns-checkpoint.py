import os
import tempfile
from typing import Any, Dict, Literal, Optional

import numpy as np
import pandas as pd
from langchain_core.tools import tool
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer

import PAMI.extras.convert.DF2DB as DF2DB
import PAMI.frequentPattern.basic.FPGrowth as FPGrowthModule
import PAMI.frequentPattern.maximal.MaxFPGrowth as MaxFPGrowthModule
import PAMI.frequentPattern.topk.FAE as TopKModule


def make_tools(session):
    @tool
    def mine_patterns_tool(
        category_name: str,
        filtering_method: Literal["variance", "tfidf", "term_frequency"],
        algorithm: Literal["fpgrowth", "topk", "maxfpgrowth"] = "fpgrowth",
        min_sup: Optional[int] = None,
        k: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Mine frequent word patterns for a specific category using PAMI algorithms.

        Builds a category-local DTM with English stop words removed, applies the chosen
        vocabulary filter (variance, tfidf, or term_frequency), converts non-empty document
        rows into a transactional database via PAMI DF2DB, and mines patterns using fpgrowth,
        topk, or maxfpgrowth. Leaves global session DTM and working DataFrame unchanged.

        Args:
            category_name: Category label to mine.
            filtering_method: Vocabulary filter ('variance', 'tfidf', or 'term_frequency').
            algorithm: PAMI mining algorithm ('fpgrowth', 'topk', or 'maxfpgrowth', default: 'fpgrowth').
            min_sup: Required for 'fpgrowth' and 'maxfpgrowth' (minimum support integer).
            k: Required for 'topk' (number of top patterns integer).

        Returns:
            A summary dictionary containing result_id, category_name, filtering_method,
            algorithm, patterns list, and kept_terms.
        """
        if session.dataframe is None:
            return {"status": "error", "message": "No dataset loaded in session.dataframe."}

        if "category_name" not in session.dataframe.columns or "text" not in session.dataframe.columns:
            return {
                "status": "error",
                "message": "Required columns 'category_name' or 'text' missing from session.dataframe.",
            }

        # Algorithm argument validation
        if algorithm in ["fpgrowth", "maxfpgrowth"] and (min_sup is None or min_sup <= 0):
            return {
                "status": "error",
                "message": f"Algorithm '{algorithm}' requires a positive integer for min_sup.",
            }

        if algorithm == "topk" and (k is None or k <= 0):
            return {
                "status": "error",
                "message": "Algorithm 'topk' requires a positive integer for k.",
            }

        args_payload = {
            "category_name": category_name,
            "filtering_method": filtering_method,
            "algorithm": algorithm,
            "min_sup": min_sup,
            "k": k,
        }

        # Filter working DataFrame to category_name
        category_df = session.dataframe[session.dataframe["category_name"] == category_name]
        if len(category_df) == 0:
            return {
                "status": "error",
                "message": f"Category '{category_name}' not found in session.dataframe.",
            }

        texts = category_df["text"].fillna("").astype(str).tolist()

        # Step 1: Build category-local DTM dropping English stop words
        vectorizer = CountVectorizer(stop_words="english")
        try:
            local_counts = vectorizer.fit_transform(texts).toarray().astype(np.float64)
            local_terms = vectorizer.get_feature_names_out().tolist()
        except ValueError:
            # Handles "empty vocabulary; perhaps the documents only contain stop words"
            result_id = session.next_result_id("mine_patterns")
            summary = {
                "result_id": result_id,
                "category_name": category_name,
                "filtering_method": filtering_method,
                "algorithm": algorithm,
                "patterns": [],
                "kept_terms": [],
                "note": "vocabulary was empty after stopword removal",
            }
            session.store_result("mine_patterns_tool", args=args_payload, summary=summary)
            session.artifacts[f"patterns_{category_name}_{filtering_method}_{algorithm}"] = []
            return summary

        if len(local_terms) == 0:
            result_id = session.next_result_id("mine_patterns")
            summary = {
                "result_id": result_id,
                "category_name": category_name,
                "filtering_method": filtering_method,
                "algorithm": algorithm,
                "patterns": [],
                "kept_terms": [],
                "note": "vocabulary was empty after stopword removal",
            }
            session.store_result("mine_patterns_tool", args=args_payload, summary=summary)
            session.artifacts[f"patterns_{category_name}_{filtering_method}_{algorithm}"] = []
            return summary

        # Step 2: Apply chosen vocabulary filtering method
        if filtering_method == "variance":
            scores = np.var(local_counts, axis=0, ddof=0)
            low, high = np.percentile(scores, 5), np.percentile(scores, 95)
            kept_indices = [i for i, s in enumerate(scores) if low <= s <= high]
        elif filtering_method == "term_frequency":
            scores = local_counts.sum(axis=0)
            low, high = np.percentile(scores, 5), np.percentile(scores, 95)
            kept_indices = [i for i, s in enumerate(scores) if low <= s <= high]
        elif filtering_method == "tfidf":
            tfidf_matrix = TfidfTransformer().fit_transform(local_counts).toarray()
            scores = tfidf_matrix.mean(axis=0)
            p20 = np.percentile(scores, 20)
            kept_indices = [i for i, s in enumerate(scores) if s >= p20]
        else:
            return {"status": "error", "message": f"Unsupported filtering_method '{filtering_method}'."}

        kept_terms = [local_terms[i] for i in kept_indices]

        # Step 3: Handle zero terms surviving filtering
        if len(kept_terms) == 0:
            result_id = session.next_result_id("mine_patterns")
            summary = {
                "result_id": result_id,
                "category_name": category_name,
                "filtering_method": filtering_method,
                "algorithm": algorithm,
                "patterns": [],
                "kept_terms": [],
                "note": "no terms survived filtering",
            }
            session.store_result("mine_patterns_tool", args=args_payload, summary=summary)
            session.artifacts[f"patterns_{category_name}_{filtering_method}_{algorithm}"] = []
            return summary

        # Step 4: Convert retained raw counts to transactional DB using PAMI DF2DB
        retained_counts = local_counts[:, kept_indices]
        retained_df = pd.DataFrame(retained_counts, columns=kept_terms)

        temp_db = tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".txt")
        temp_db_path = temp_db.name
        temp_db.close()

        try:
            converter = DF2DB.DF2DB(retained_df, DFtype="dense")
            converter.convert2TransactionalDatabase(temp_db_path, condition=">=", thresholdValue=1)

            # Step 5: Mine using PAMI algorithm
            patterns = []
            if algorithm == "fpgrowth":
                miner = FPGrowthModule.FPGrowth(temp_db_path, minSup=min_sup, sep="\t")
                miner.mine()
                df_res = miner.getPatternsAsDataFrame()
                if df_res is not None and not df_res.empty:
                    for _, r in df_res.iterrows():
                        pat_str = str(r["Patterns"]).strip()
                        pat_list = pat_str.split("\t") if "\t" in pat_str else pat_str.split()
                        patterns.append({"pattern": pat_list, "support": int(r["Support"])})
            elif algorithm == "topk":
                miner = TopKModule.FAE(temp_db_path, k=k, sep="\t")
                miner.mine()
                df_res = miner.getPatternsAsDataFrame()
                if df_res is not None and not df_res.empty:
                    for _, r in df_res.iterrows():
                        pat_str = str(r["Patterns"]).strip()
                        pat_list = pat_str.split("\t") if "\t" in pat_str else pat_str.split()
                        patterns.append({"pattern": pat_list, "support": int(r["Support"])})
            elif algorithm == "maxfpgrowth":
                miner = MaxFPGrowthModule.MaxFPGrowth(temp_db_path, minSup=min_sup, sep="\t")
                miner.mine()
                df_res = miner.getPatternsAsDataFrame()
                if df_res is not None and not df_res.empty:
                    for _, r in df_res.iterrows():
                        pat_str = str(r["Patterns"]).strip()
                        pat_list = pat_str.split("\t") if "\t" in pat_str else pat_str.split()
                        patterns.append({"pattern": pat_list, "support": int(r["Support"])})

            result_id = session.next_result_id("mine_patterns")
            summary = {
                "result_id": result_id,
                "category_name": category_name,
                "filtering_method": filtering_method,
                "algorithm": algorithm,
                "patterns": patterns,
                "kept_terms": kept_terms,
            }

            session.store_result("mine_patterns_tool", args=args_payload, summary=summary)
            session.artifacts[f"patterns_{category_name}_{filtering_method}_{algorithm}"] = patterns
            return summary

        finally:
            if os.path.exists(temp_db_path):
                os.remove(temp_db_path)

    return [mine_patterns_tool]
